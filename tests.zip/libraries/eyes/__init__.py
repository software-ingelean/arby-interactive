"""Arby eyes modules."""
