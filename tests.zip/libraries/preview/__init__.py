"""Arby preview components."""
