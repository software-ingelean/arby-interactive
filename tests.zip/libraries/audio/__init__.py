"""Arby audio modules."""
