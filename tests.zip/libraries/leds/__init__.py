"""Arby leds modules."""
