"""Arby bot modules."""
